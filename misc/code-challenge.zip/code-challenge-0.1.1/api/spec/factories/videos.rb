# frozen_string_literal: true

FactoryBot.define do
  factory :video do
    title { 'video title' }
    category
  end
end
