class Video < ApplicationRecord

end
